import { createFileRoute } from "@tanstack/react-router";
import { useState, useEffect } from "react";

export const Route = createFileRoute("/admin/dashboard")({
  component: Dashboard,
});

type Stats = {
  total: number;
  pending: number;
  contacted: number;
  completed: number;
  cancelled: number;
  today: number;
  thisWeek: number;
  servicesTotal: number;
  servicesActive: number;
};

type Submission = {
  id: string;
  full_name: string;
  email: string;
  status: string;
  created_at: string;
};

const STATUS_META: Record<string, { label: string; color: string; bg: string; lightBg: string }> = {
  pending: { label: "Pendente", color: "#eab308", bg: "bg-yellow-100", lightBg: "bg-yellow-50" },
  contacted: { label: "Contactado", color: "#3b82f6", bg: "bg-blue-100", lightBg: "bg-blue-50" },
  completed: { label: "Concluído", color: "#22c55e", bg: "bg-green-100", lightBg: "bg-green-50" },
  cancelled: { label: "Cancelado", color: "#ef4444", bg: "bg-red-100", lightBg: "bg-red-50" },
};

function Dashboard() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [recentSubs, setRecentSubs] = useState<Submission[]>([]);

  useEffect(() => {
    import("@/lib/admin.server").then(({ getStats, getSubmissions }) => {
      getStats().then(setStats);
      getSubmissions().then((data: Submission[]) => setRecentSubs(data.slice(0, 5)));
    });
  }, []);

  if (!stats) {
    return (
      <div className="p-6 space-y-6">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="h-32 rounded-2xl bg-gray-100 animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  const completionRate = stats.total > 0 ? Math.round((stats.completed / stats.total) * 100) : 0;
  const pendingRate = stats.total > 0 ? Math.round((stats.pending / stats.total) * 100) : 0;
  const contactedRate = stats.total > 0 ? Math.round((stats.contacted / stats.total) * 100) : 0;

  const mainCards = [
    { label: "Total Submissões", value: stats.total, icon: "M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z", color: "#007473" },
    { label: "Pendentes", value: stats.pending, icon: "M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z", color: "#eab308" },
    { label: "Contactados", value: stats.contacted, icon: "M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z", color: "#3b82f6" },
    { label: "Concluídos", value: stats.completed, icon: "M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z", color: "#22c55e" },
  ];

  const distributionData = [
    { label: "Pendentes", value: stats.pending, color: "#eab308" },
    { label: "Contactados", value: stats.contacted, color: "#3b82f6" },
    { label: "Concluídos", value: stats.completed, color: "#22c55e" },
    { label: "Cancelados", value: stats.cancelled, color: "#ef4444" },
  ];

  const totalForDist = distributionData.reduce((a, b) => a + b.value, 0) || 1;

  return (
    <div className="p-6 space-y-6">
      {/* Page header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-sm text-gray-500 mt-1">Visão geral do sistema</p>
      </div>

      {/* Main stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {mainCards.map((card) => (
          <div key={card.label} className="bg-white rounded-2xl border border-gray-100 p-5 hover:shadow-lg hover:border-gray-200 transition-all duration-200">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">{card.label}</span>
              <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${card.color}12` }}>
                <svg className="w-5 h-5" style={{ color: card.color }} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d={card.icon} />
                </svg>
              </div>
            </div>
            <p className="text-3xl font-bold text-gray-900">{card.value}</p>
            <div className="mt-2 h-1 rounded-full bg-gray-100 overflow-hidden">
              <div className="h-full rounded-full transition-all duration-700" style={{ width: `${stats.total > 0 ? Math.round((card.value / stats.total) * 100) : 0}%`, backgroundColor: card.color }} />
            </div>
          </div>
        ))}
      </div>

      {/* Second row: progress, distribution, recent */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Progress card */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6">
          <h3 className="text-sm font-semibold text-gray-900 mb-5 flex items-center gap-2">
            <svg className="w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 013 19.875v-6.75zM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V8.625zM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V4.125z" />
            </svg>
            Progresso Geral
          </h3>
          <div className="space-y-5">
            <div>
              <div className="flex items-center justify-between text-sm mb-1.5">
                <span className="text-gray-500">Concluídos</span>
                <span className="font-semibold text-gray-900">{completionRate}%</span>
              </div>
              <div className="h-3 rounded-full bg-gray-100 overflow-hidden">
                <div className="h-full rounded-full bg-green-500 transition-all duration-700" style={{ width: `${completionRate}%` }} />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between text-sm mb-1.5">
                <span className="text-gray-500">Contactados</span>
                <span className="font-semibold text-gray-900">{contactedRate}%</span>
              </div>
              <div className="h-3 rounded-full bg-gray-100 overflow-hidden">
                <div className="h-full rounded-full bg-blue-500 transition-all duration-700" style={{ width: `${contactedRate}%` }} />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between text-sm mb-1.5">
                <span className="text-gray-500">Pendentes</span>
                <span className="font-semibold text-gray-900">{pendingRate}%</span>
              </div>
              <div className="h-3 rounded-full bg-gray-100 overflow-hidden">
                <div className="h-full rounded-full bg-yellow-500 transition-all duration-700" style={{ width: `${pendingRate}%` }} />
              </div>
            </div>
            <div className="pt-3 border-t border-gray-100">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-500">Serviços</span>
                <span className="font-semibold text-gray-900">{stats.servicesActive}/{stats.servicesTotal} activos</span>
              </div>
            </div>
          </div>
        </div>

        {/* Distribution chart */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6">
          <h3 className="text-sm font-semibold text-gray-900 mb-5 flex items-center gap-2">
            <svg className="w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 6.75h12M8.25 12h12m-12 5.25h12M3.75 6.75h.007v.008H3.75V6.75zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zM3.75 12h.007v.008H3.75V12zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm-.375 5.25h.007v.008H3.75v-.008zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
            </svg>
            Distribuição
          </h3>
          <div className="space-y-4">
            {distributionData.map((d) => (
              <div key={d.label} className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: d.color }} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between text-sm mb-1">
                    <span className="text-gray-600">{d.label}</span>
                    <span className="font-semibold text-gray-900">{d.value}</span>
                  </div>
                  <div className="h-2 rounded-full bg-gray-100 overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-700" style={{ width: `${(d.value / totalForDist) * 100}%`, backgroundColor: d.color }} />
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-5 pt-4 border-t border-gray-100 grid grid-cols-2 gap-3 text-center">
            <div>
              <p className="text-xs text-gray-500">Hoje</p>
              <p className="text-lg font-bold text-gray-900">{stats.today}</p>
            </div>
            <div>
              <p className="text-xs text-gray-500">Esta Semana</p>
              <p className="text-lg font-bold text-gray-900">{stats.thisWeek}</p>
            </div>
          </div>
        </div>

        {/* Recent submissions */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6">
          <h3 className="text-sm font-semibold text-gray-900 mb-5 flex items-center gap-2">
            <svg className="w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M11.48 3.499a.562.562 0 011.04 0l2.125 5.111a.563.563 0 00.475.345l5.518.442c.499.04.701.663.321.988l-4.204 3.602a.563.563 0 00-.182.557l1.285 5.385a.562.562 0 01-.84.61l-4.725-2.885a.563.563 0 00-.586 0L6.982 20.54a.562.562 0 01-.84-.61l1.285-5.386a.562.562 0 00-.182-.557l-4.204-3.602a.563.563 0 01.321-.988l5.518-.442a.563.563 0 00.475-.345L11.48 3.5z" />
            </svg>
            Submissões Recentes
          </h3>
          {recentSubs.length === 0 ? (
            <div className="text-center py-10 text-gray-400">
              <svg className="w-10 h-10 mx-auto mb-2 text-gray-200" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
              </svg>
              <p className="text-sm font-medium">Nenhuma submissão</p>
            </div>
          ) : (
            <div className="space-y-2">
              {recentSubs.map((s, idx) => {
                const meta = STATUS_META[s.status] || STATUS_META.pending;
                return (
                  <div key={s.id} className="flex items-center gap-3 p-3 rounded-xl hover:bg-gray-50 transition-colors" style={{ animationDelay: `${idx * 50}ms` }}>
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center text-white text-xs font-bold flex-shrink-0" style={{ backgroundColor: meta.color }}>
                      {s.full_name.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-gray-900 truncate">{s.full_name}</p>
                      <p className="text-xs text-gray-400">{new Date(s.created_at).toLocaleDateString("pt-AO")}</p>
                    </div>
                    <span className={`px-2.5 py-1 text-xs font-semibold rounded-full ${meta.bg} flex-shrink-0`} style={{ color: meta.color }}>
                      {meta.label}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
