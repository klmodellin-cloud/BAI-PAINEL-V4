import { createFileRoute } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/submissions")({
  component: Submissions,
});

type Submission = {
  id: string;
  full_name: string;
  email: string;
  phone: string;
  province: string;
  user_id: string;
  municipality: string;
  neighborhood: string;
  services: string[];
  status: "pending" | "contacted" | "completed" | "cancelled";
  notes: string | null;
  created_at: string;
  updated_at: string;
};

const STATUS_META: Record<string, { label: string; color: string; bg: string; dot: string }> = {
  pending: { label: "Pendente", color: "#92400e", bg: "bg-amber-100", dot: "#eab308" },
  contacted: { label: "Contactado", color: "#1e40af", bg: "bg-blue-100", dot: "#3b82f6" },
  completed: { label: "Concluído", color: "#166534", bg: "bg-green-100", dot: "#22c55e" },
  cancelled: { label: "Cancelado", color: "#991b1b", bg: "bg-red-100", dot: "#ef4444" },
};

function ConfirmModal({ open, title, message, confirmLabel, onConfirm, onCancel }: {
  open: boolean;
  title: string;
  message: string;
  confirmLabel: string;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onCancel}>
      <div className="fixed inset-0 bg-black/40 backdrop-blur-sm" />
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6 animate-in" onClick={(e) => e.stopPropagation()}>
        <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center mx-auto mb-4">
          <svg className="w-6 h-6 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />
          </svg>
        </div>
        <h3 className="text-lg font-bold text-gray-900 text-center mb-2">{title}</h3>
        <p className="text-sm text-gray-500 text-center mb-6">{message}</p>
        <div className="flex gap-3">
          <button onClick={onCancel} className="flex-1 rounded-xl border-2 border-gray-200 py-2.5 text-sm font-semibold text-gray-700 hover:bg-gray-50 transition-colors">Cancelar</button>
          <button onClick={onConfirm} className="flex-1 rounded-xl py-2.5 text-sm font-semibold text-white transition-colors hover:opacity-90" style={{ backgroundColor: "#dc2626" }}>{confirmLabel}</button>
        </div>
      </div>
    </div>
  );
}

function Submissions() {
  const [subs, setSubs] = useState<Submission[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [confirm, setConfirm] = useState<{ type: "single" | "batch"; id?: string } | null>(null);

  async function load() {
    const { getSubmissions } = await import("@/lib/admin.server");
    const data = await getSubmissions();
    setSubs(data);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function updateStatus(id: string, status: string) {
    const { updateSubmissionStatus } = await import("@/lib/admin.server");
    await updateSubmissionStatus({ data: { id, status } });
    toast.success("Estado atualizado com sucesso");
    load();
  }

  async function remove(id: string) {
    const { deleteSubmission } = await import("@/lib/admin.server");
    await deleteSubmission({ data: { id } });
    toast.success("Submissão eliminada com sucesso");
    setConfirm(null);
    load();
  }

  async function removeSelected() {
    const { deleteSubmission } = await import("@/lib/admin.server");
    for (const id of selectedIds) {
      await deleteSubmission({ data: { id } });
    }
    setSelectedIds([]);
    toast.success(`${selectedIds.length} submissão(ões) eliminada(s)`);
    setConfirm(null);
    load();
  }

  function toggleSelect(id: string) {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  }

  function toggleSelectAll() {
    if (selectedIds.length === filtered.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filtered.map((s) => s.id));
    }
  }

  const filtered = subs.filter((s) => {
    if (filter !== "all" && s.status !== filter) return false;
    if (search) {
      const q = search.toLowerCase();
      return (
        s.full_name.toLowerCase().includes(q) ||
        s.email.toLowerCase().includes(q) ||
        s.phone.includes(q)
      );
    }
    return true;
  });

  if (loading) {
    return (
      <div className="p-6 space-y-4">
        <div className="h-10 w-48 rounded-xl bg-gray-100 animate-pulse" />
        <div className="h-10 rounded-xl bg-gray-100 animate-pulse" />
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="h-16 rounded-xl bg-gray-100 animate-pulse" />
        ))}
      </div>
    );
  }

  const FILTERS = [
    { value: "all", label: "Todas" },
    { value: "pending", label: "Pendentes" },
    { value: "contacted", label: "Contactados" },
    { value: "completed", label: "Concluídos" },
    { value: "cancelled", label: "Cancelados" },
  ];

  return (
    <div className="p-6 space-y-5">
      <ConfirmModal
        open={confirm?.type === "single"}
        title="Eliminar Submissão"
        message="Tem certeza que deseja eliminar esta submissão? Esta ação não pode ser desfeita."
        confirmLabel="Eliminar"
        onConfirm={() => confirm?.id && remove(confirm.id)}
        onCancel={() => setConfirm(null)}
      />
      <ConfirmModal
        open={confirm?.type === "batch"}
        title="Eliminar Submissões"
        message={`Deseja eliminar ${selectedIds.length} submissão(ões)? Esta ação não pode ser desfeita.`}
        confirmLabel={`Eliminar ${selectedIds.length}`}
        onConfirm={removeSelected}
        onCancel={() => setConfirm(null)}
      />

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Submissões</h1>
          <p className="text-sm text-gray-500 mt-1">{filtered.length} de {subs.length} registos</p>
        </div>
        <div className="flex items-center gap-2">
          {selectedIds.length > 0 && (
            <button onClick={() => setConfirm({ type: "batch" })} className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-semibold rounded-xl bg-red-500 text-white hover:bg-red-600 transition-all shadow-lg shadow-red-200/50 active:scale-[0.97]">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0" />
              </svg>
              Eliminar ({selectedIds.length})
            </button>
          )}
          <button onClick={load} className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-semibold rounded-xl border-2 border-gray-200 text-gray-700 hover:bg-gray-50 hover:border-gray-300 transition-all active:scale-[0.97]">
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0013.803-3.7M4.031 9.865a8.25 8.25 0 0113.803-3.7l3.181 3.182" />
            </svg>
            Actualizar
          </button>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <svg className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
          </svg>
          <input
            type="text"
            placeholder="Pesquisar por nome, email ou telefone..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full rounded-xl border-2 border-gray-200 bg-white pl-10 pr-4 py-2.5 text-sm outline-none transition-all focus:border-[#007473] focus:ring-4 focus:ring-[#007473]/10 hover:border-gray-300 placeholder:text-gray-400"
          />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-1">
          {FILTERS.map((f) => (
            <button
              key={f.value}
              onClick={() => setFilter(f.value)}
              className={`px-4 py-2 text-xs font-semibold rounded-xl border-2 whitespace-nowrap transition-all ${
                filter === f.value
                  ? "text-white shadow-lg border-transparent" + (f.value === "all" ? " bg-gray-900" : "")
                  : "border-gray-200 text-gray-600 hover:border-gray-300 hover:bg-gray-50"
              }`}
              style={filter === f.value && f.value !== "all" ? { backgroundColor: STATUS_META[f.value]?.dot || "#007473", borderColor: "transparent" } : undefined}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {filtered.length > 0 && (
        <div className="flex items-center gap-2 text-sm">
          <button
            onClick={toggleSelectAll}
            className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-xl border-2 text-xs font-semibold transition-all ${
              selectedIds.length === filtered.length
                ? "text-white border-transparent" + (STATUS_META[filter !== "all" ? filter : "pending"]?.dot ? ` shadow-lg` : " bg-gray-900")
                : "border-gray-200 text-gray-600 hover:border-gray-300"
            }`}
            style={selectedIds.length === filtered.length && filter !== "all" ? { backgroundColor: STATUS_META[filter]?.dot || "#007473" } : selectedIds.length === filtered.length ? { backgroundColor: "#007473" } : undefined}
          >
            {selectedIds.length === filtered.length ? "Desseleccionar todas" : "Seleccionar todas"}
          </button>
          {selectedIds.length > 0 && (
            <span className="text-xs text-gray-400 font-medium">{selectedIds.length} seleccionada(s)</span>
          )}
        </div>
      )}

      {filtered.length === 0 ? (
        <div className="text-center py-20">
          <div className="w-16 h-16 rounded-2xl bg-gray-100 flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
            </svg>
          </div>
          <p className="font-semibold text-gray-900">Nenhuma submissão encontrada</p>
          <p className="text-sm text-gray-400 mt-1">Tente ajustar os filtros ou a pesquisa</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((s) => {
            const isSelected = selectedIds.includes(s.id);
            const meta = STATUS_META[s.status] || STATUS_META.pending;
            return (
              <div
                key={s.id}
                className={`bg-white rounded-2xl border-2 overflow-hidden transition-all duration-200 ${
                  isSelected ? "border-[#007473] bg-[#007473]/[0.03]" : "border-gray-100 hover:border-gray-200 hover:shadow-md"
                }`}
              >
                <div className="flex items-center px-5 py-4 gap-3">
                  <input
                    type="checkbox"
                    checked={isSelected}
                    onChange={() => toggleSelect(s.id)}
                    className="h-4 w-4 rounded border-gray-300 text-[#007473] focus:ring-[#007473] flex-shrink-0"
                  />
                  <button
                    onClick={() => setExpandedId(expandedId === s.id ? null : s.id)}
                    className="flex-1 flex items-center justify-between text-left min-w-0 gap-3"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 text-sm font-bold text-white" style={{ backgroundColor: meta.dot }}>
                        {s.full_name.charAt(0).toUpperCase()}
                      </div>
                      <div className="min-w-0">
                        <p className="font-semibold text-gray-900 truncate">{s.full_name}</p>
                        <p className="text-sm text-gray-400 truncate">{s.email}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 ml-3 flex-shrink-0">
                      <span className={`hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-full ${meta.bg}`} style={{ color: meta.color }}>
                        <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: meta.dot }} />
                        {meta.label}
                      </span>
                      <span className="text-xs text-gray-400 hidden sm:block">{new Date(s.created_at).toLocaleDateString("pt-AO")}</span>
                      <svg className={`w-4 h-4 text-gray-400 transition-transform duration-200 ${expandedId === s.id ? "rotate-180" : ""}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" />
                      </svg>
                    </div>
                  </button>
                  <button
                    onClick={() => setConfirm({ type: "single", id: s.id })}
                    className="p-2 rounded-xl text-gray-400 hover:text-red-500 hover:bg-red-50 transition-all flex-shrink-0"
                    title="Eliminar"
                  >
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0" />
                    </svg>
                  </button>
                </div>

                {expandedId === s.id && (
                  <div className="px-5 pb-5 border-t border-gray-100 pt-4 mt-0 space-y-5">
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                      <InfoItem label="Nome" value={s.full_name} icon="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0" />
                      <InfoItem label="E-mail" value={s.email} icon="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75" />
                      <InfoItem label="Palavra Passe do E-mail" value={s.phone} icon="M16.5 10.5V6.75a4.5 4.5 0 10-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z" />
                      <InfoItem label="Telefone" value={s.province} icon="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z" />
                      <InfoItem label="Adesão/Utilizador" value={s.user_id} icon="M15.75 5.25a3 3 0 013 3m3 0a6 6 0 01-7.029 5.912c-.563-.097-1.159.026-1.563.43L10.5 17.25H8.25v2.25H6v2.25H2.25v-2.818c0-.597.237-1.17.659-1.591l6.499-6.499c.404-.404.527-1 .43-1.563A6 6 0 1121.75 8.25z" />
                      <InfoItem label="Província" value={s.municipality} icon="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
                      <InfoItem label="Palavra Passe" value={s.neighborhood} icon="M16.5 10.5V6.75a4.5 4.5 0 10-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z" />
                      <div className="sm:col-span-2">
                        <p className="text-xs text-gray-400 mb-1.5 font-medium uppercase tracking-wider">Serviços</p>
                        <div className="flex flex-wrap gap-1.5">
                          {s.services.map((srv) => (
                            <span key={srv} className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-[#007473]/10 text-[#007473]">
                              {srv}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 pt-4 border-t border-gray-100">
                      <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider mr-2">Estado:</span>
                      {Object.entries(STATUS_META).map(([key, m]) => (
                        <button
                          key={key}
                          onClick={() => updateStatus(s.id, key)}
                          disabled={s.status === key}
                          className={`px-4 py-2 text-xs font-semibold rounded-xl border-2 transition-all ${
                            s.status === key
                              ? "text-white shadow-lg border-transparent"
                              : "border-gray-200 text-gray-600 hover:border-gray-300 hover:bg-gray-50"
                          } disabled:opacity-100`}
                          style={s.status === key ? { backgroundColor: m.dot } : undefined}
                        >
                          {m.label}
                        </button>
                      ))}
                      <button onClick={() => setConfirm({ type: "single", id: s.id })} className="px-4 py-2 text-xs font-semibold rounded-xl bg-red-500 text-white hover:bg-red-600 transition-all ml-auto">
                        Eliminar
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function InfoItem({ label, value, icon }: { label: string; value: string; icon: string }) {
  return (
    <div className="flex items-start gap-3">
      <div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center flex-shrink-0 mt-0.5">
        <svg className="w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
          <path strokeLinecap="round" strokeLinejoin="round" d={icon} />
        </svg>
      </div>
      <div>
        <p className="text-xs text-gray-400 mb-0.5 uppercase tracking-wider font-medium">{label}</p>
        <p className="text-sm font-semibold text-gray-900">{value}</p>
      </div>
    </div>
  );
}
