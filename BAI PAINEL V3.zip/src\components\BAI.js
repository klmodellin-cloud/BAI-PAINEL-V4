import type { SVGProps } from "react";

const BAI = (props: SVGProps<SVGSVGElement>) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 100 100"
    {...props}
  >
    <rect width="100" height="100" fill="currentColor" />
    <rect y="33" width="100" height="34" fill="#ffffff" />
  </svg>
);
export default BAI;
