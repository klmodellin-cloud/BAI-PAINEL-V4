import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";

export const Route = createFileRoute("/test-deployment")({
  component: TestDeployment,
});

function TestDeployment() {
  const [inputValue, setInputValue] = useState("");
  const [items, setItems] = useState<string[]>([]);

  const addItem = () => {
    if (inputValue.trim()) {
      setItems((prev) => [...prev, inputValue.trim()]);
      setInputValue("");
    }
  };

  const clearAll = () => {
    setItems([]);
  };

  return (
    <div className="min-h-screen bg-white p-8 text-foreground">
      <div className="max-w-md mx-auto space-y-6">
        <h1 className="text-2xl font-bold">Test Deployment</h1>
        <p className="text-muted-foreground">
          Testing state persistence and input fields.
        </p>

        <div className="flex gap-2">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Type something..."
            className="flex-1 rounded-lg border border-border bg-white px-4 py-2 text-foreground shadow-sm focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                addItem();
              }
            }}
          />
          <button
            onClick={addItem}
            className="rounded-lg bg-primary px-4 py-2 font-semibold text-primary-foreground shadow hover:bg-primary/90 transition-colors"
          >
            Add
          </button>
        </div>

        {items.length > 0 && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">
                Items ({items.length})
              </h2>
              <button
                onClick={clearAll}
                className="rounded-lg border border-border bg-white px-3 py-1 text-sm font-medium text-foreground shadow-sm hover:bg-muted transition-colors"
              >
                Clear All
              </button>
            </div>
            <ul className="space-y-1">
              {items.map((item, index) => (
                <li
                  key={index}
                  className="rounded-lg border border-border bg-white px-4 py-2 text-sm shadow-sm"
                >
                  {item}
                </li>
              ))}
            </ul>
          </div>
        )}

        <p className="text-sm text-muted-foreground border-t border-border pt-4">
          This page tests that state updates work correctly after deployment.
        </p>
      </div>
    </div>
  );
}
