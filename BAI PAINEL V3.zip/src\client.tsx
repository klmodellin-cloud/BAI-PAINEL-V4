import { StrictMode, startTransition } from "react";
import { hydrateRoot } from "react-dom/client";
import "./styles.css";
import { StartClient } from "@tanstack/react-start/client";

startTransition(() => {
  hydrateRoot(
    document,
    <StrictMode>
      <StartClient />
    </StrictMode>,
  );
});
