import { createServerFn } from "@tanstack/react-start";

export type User = {
  id: string;
  name: string;
  email: string;
};

export const users: Record<string, User> = {
  usr_01JAD0AHZRG1E86WZG0314M6FW: {
    id: "usr_01JAD0AHZRG1E86WZG0314M6FW",
    name: "Niklas Kunkel",
    email: "niklas@lovable.dev",
  },
};

export const getUser = createServerFn({ method: "GET" })
  .validator((userId: string) => userId)
  .handler(async ({ data }) => {
    return users[data] ?? null;
  });
